# Cookie-Clicker-Source-Code-Beta
2.021 source code for... educational purposes... BETA edition! <br>
Download and Extract to delete free time.. BETA EDITION! Or just use the website. <br> <br>
Do not worry, I will be updating this to be up to date with the current Cookie Clicker beta version. <br>
<!-- Well guess what, 2.021 came out... what happened to 2.020??  -->
Credits obviously go Orteil, visit the official website here: http://orteil.dashnet.org/cookieclicker/
